<?php 
if ( file_exists( dirname( __FILE__ ) . 'inc/cmb2/init.php' ) ) {
	require_once dirname( __FILE__ ) . 'inc/cmb2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/CMB2/init.php';
}

function basica_cmb2(){
	
	$prefix  = '_basica_theme_';
	
	$service_item = new_cmb2_box(array(
	'id'     =>  $prefix.'service_metabox',
	'title'  =>  'Service Metabox',
	'object_types' => array('services'),
	'priority'    => 'high',
	'show_names'  =>  true
	
	));
	$service_item->add_field(array(
	'name'    =>   'Service Icon',
	'id'      =>   $prefix.'service_icon',
	'desc'    =>   'Enter here service icon font awesome name',
	'type'    =>   'text'
  	));
	$service_item->add_field(array(
	'name'    =>   'Service Title',
	'id'      =>   $prefix.'service_title',
	'desc'    =>   'Enter here service title',
	'type'    =>   'text'
  	));
	$service_item->add_field(array(
	'name'    =>   'Service Description',
	'id'      =>   $prefix.'service_description',
	'desc'    =>   'Enter here service description',
	'type'    =>   'text'
  	));
	$service_item->add_field(array(
	'name'    =>   'Service Link',
	'id'      =>   $prefix.'service_link',
	'desc'    =>   'Enter here service link',
	'type'    =>   'text'
  	));
	$service_item->add_field(array(
	'name'    =>   'Service Link Text',
	'id'      =>   $prefix.'service_link_text',
	'desc'    =>   'Enter here service link text',
	'type'    =>   'text'
  	));
	
	
	
	
}
add_action('cmb2_admin_init', 'basica_cmb2');