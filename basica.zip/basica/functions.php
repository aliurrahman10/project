<?php

require_once('wp-bootstrap-navwalker.php');
require_once('inc/Redux/redux-framework.php');
require_once('inc/basica-theme-options.php');
include_once('inc/basica-fields-options.php');



function basica_scripts(){
	wp_enqueue_style('bootsrap', get_template_directory_uri().'/css/bootstrap.css',null,'1','all');
	wp_enqueue_style('main', get_template_directory_uri().'/css/main.css',null,'1','all');
	wp_enqueue_style('custom', get_template_directory_uri().'/css/custom.css',null,'1','all');
	wp_enqueue_style('icomoon-social', get_template_directory_uri().'/css/icomoon-social.css',null,'1','all');
	wp_enqueue_style('font-awesome', get_template_directory_uri().'/css/font-awesome.min.css',null,'1','all');
    wp_enqueue_style('basica', get_stylesheet_uri(), null, '1', 'all');
	
	
	wp_enqueue_script('modernizr-2', get_template_directory_uri().'/js/modernizr-2.6.2-respond-1.1.0.min.js',null,'1',false);
	wp_enqueue_script('jquery-1', get_template_directory_uri().'/js/jquery-1.9.1.min.js',null,'1',true);
	wp_enqueue_script('bootsrap', get_template_directory_uri().'/js/bootstrap.min.js',null,'1',true);
	wp_enqueue_script('easing', get_template_directory_uri().'/js/jquery.easing.min.js',null,'1',true);
	wp_enqueue_script('scrolling-nav', get_template_directory_uri().'/js/scrolling-nav.js',null,'1',true);
}

add_action('wp_enqueue_scripts', 'basica_scripts');



function basica_theme_supports(){
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	
	
	register_nav_menus(array(
	'main-menu'    =>    'Main Menu'
	));
	
	
	
	function read_more($limit){
	$post_content =explode(" ", get_the_content());
	
    $less_content =array_slice($post_content,0,$limit);
	
	echo implode(" ", $less_content);
}

}

add_action('after_setup_theme', 'basica_theme_supports');




function basica_custom_posts(){
	register_post_type('slider',array(
	'labels'     =>   array(
	'name'       =>   'Slider',
	'all_items'  =>   'All slider',
	),
	'public'     =>   true,
	'supports'   =>   array(
	'title', 'editor', 'page-attributes', 'custom-fields', 'thumbnail'
	)
	));
	register_post_type('services',array(
	'labels'     =>   array(
	'name'       =>   'Services',
	'all_items'  =>   'All services',
	),
	'public'     =>   true,
	'supports'   =>   array(
      'custom-fields'
	)
	));
}

add_action('init','basica_custom_posts');


function basica_sidebar(){
 register_sidebar(array(
 'name'        =>  'sidebar one',
 'description' =>  'this is sidebar one',
 'id'          =>   'sidebar_one'
 ));
  register_sidebar(array(
 'name'        =>  'sidebar two',
 'description' =>  'this is sidebar two',
 'id'          =>   'sidebar_two'
 ));
 register_sidebar(array(
 'name'        =>  'sidebar three',
 'description' =>  'this is sidebar three',
 'id'          =>   'sidebar_three'
 ));
 register_sidebar(array(
 'name'        =>  'sidebar four',
 'description' =>  'this is sidebar four',
 'id'          =>   'sidebar_four'
 ));
register_widget('my_custom');
 
}

add_action('widgets_init','basica_sidebar');

class my_custom extends WP_Widget{
	public function __construct(){
		parent:: __construct('my_custom', 'Rakib', '');
	}
}

