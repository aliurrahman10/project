<?php global $basica_theme; ?>
  <!-- Footer -->
	    <div class="footer">
	    	<div class="container">
			
		    	<div class="row">
				
		    		<div class="col-footer col-md-4 col-xs-6">
		    			<h3><?php echo $basica_theme['left_title']; ?></h3>
		    			<p class="contact-us-details">
	        			 <?php echo $basica_theme['left_text']; ?>
	        			</p>
		    		</div>				
		    		<div class="col-footer col-md-4 col-xs-6">
		    			<h3><?php echo $basica_theme['middle_title']; ?></h3>
						<p><?php echo $basica_theme['middle_text']; ?></p>
		    			<div>
						  <?php 
						  if(is_array($basica_theme['middle_icon'])){
							  foreach($basica_theme['middle_icon'] as $singlevalue){?>
							  
							<img src="<?php echo $singlevalue['image']; ?>" width="32" alt="Facebook">
								
							  <?php }
						  }
						  ?>
						</div>
		    		</div>
		    		<div class="col-footer col-md-4 col-xs-6">
		    			<h3><?php echo $basica_theme['right_title']; ?></h3>
		    				<p><?php echo $basica_theme['right_text']; ?></p>
		    		</div>

		    	</div>
		    	<div class="row">
		    		<div class="col-md-12">
		    			<div class="footer-copyright">
                         &copy; <?php echo $basica_theme['copyright_text']; ?>
						</div>
		    		</div>
		    	</div>
		    </div>
	    </div>
		<?php wp_footer(); ?>
    </body>
</html>