<?php get_header(); ?>
        <!-- Page Title -->
		<div class="section section-breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h1>Blog Post</h1>
					</div>
				</div>
			</div>
		</div>
        
        <div class="section">
	    	<div class="container">
				<div class="row">
					<!-- Blog Post -->
					<?php 
					if(have_posts() ){
						while(have_posts() ){
							the_post(); ?>
							
						<div class="col-sm-8">
						<div class="blog-post blog-single-post">
							<div class="single-post-title">
								<h2><?php the_title(); ?></h2>
							</div>

							<div class="single-post-image">
								<?php the_post_thumbnail(); ?>
							</div>
							<div class="single-post-info">
								<i class="glyphicon glyphicon-time"></i><?php the_date('d M, Y'); ?> <a title="Show Comments"><i class="glyphicon glyphicon-comment"></i><?php comments_popup_link('No Comment','1 comment', '% comments'); ?></a>
							</div>							
							<div class="single-post-content">
			                 <?php the_content(); ?>
							</div>
						</div>
					</div>	
							
							
						<?php }
					}else{
						echo 'No post found';
					}
					
					?>
					
					
					
					<!-- End Blog Post -->
					<!-- Sidebar -->
					<div class="col-sm-4 blog-sidebar">
						<h4>Search our Blog</h4>
						<form>
							<div class="input-group">
								<input class="form-control input-md" id="appendedInputButtons" type="text">
								<span class="input-group-btn">
									<button class="btn btn-md" type="button">Search</button>
								</span>
							</div>
						</form>
						<h4>Recent Posts</h4>
						<ul class="recent-posts">
							<li><a href="#">Lorem ipsum dolor sit amet</a></li>
							<li><a href="#">Sed sit amet metus sit</a></li>
							<li><a href="#">Nunc et diam volutpat tellus ultrices</a></li>
							<li><a href="#">Quisque sollicitudin cursus felis</a></li>
						</ul>
						<h4>Categories</h4>
						<ul class="blog-categories">
							<li><a href="#">Lorem ipsum</a></li>
							<li><a href="#">Sed sit amet metus</a></li>
							<li><a href="#">Nunc et diam </a></li>
							<li><a href="#">Quisque</a></li>
						</ul>
						<h4>Archive</h4>
						<ul>
							<li><a href="#">January 2013</a></li>
							<li><a href="#">February 2013</a></li>
							<li><a href="#">March 2013</a></li>
							<li><a href="#">April 2013</a></li>
							<li><a href="#">May 2013</a></li>
						</ul>
					</div>
					<!-- End Sidebar -->
				</div>
			</div>
	    </div>

	  <?php get_footer(); ?>