 <?php get_header(); ?>
        <!-- Page Title -->
		<div class="section section-breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h1>Our Blog</h1>
					</div>
				</div>
			</div>
		</div>
        
        <div class="section">
	    	<div class="container">
				<div class="row">
				
				<?php 
				if(have_posts() ){
					while(have_posts() ){
						the_post(); ?>
						
						<!-- Blog Post Excerpt -->
					 <div class="col-sm-6">
						<div class="blog-post blog-single-post">
							<div class="single-post-title">
								<a href="<?php the_permalink(); ?>"<h2><?php the_title(); ?></h2></a>
							</div>

							<div class="single-post-image">
								<?php the_post_thumbnail(); ?>
							</div>
							
							<div class="single-post-info">
								<i class="glyphicon glyphicon-time"></i><?php the_time('d M, Y'); ?> <a href="#" title="Show Comments"><i class="glyphicon glyphicon-comment"></i><?php comments_popup_link('No Comment','1 comment', '% comments', 'comment_link', 'comments off'); ?></a>
							</div>
							
							<div class="single-post-content">
								<p>
									<?php read_more(20); ?>
								</p>
							<a href="<?php the_permalink(); ?>" class="btn">Read more</a>
							</div>
						</div>
					  </div>
					<!-- End Blog Post Excerpt -->	
					<?php }
				}else{
					echo 'No Post here...';
				}
				
				?>
				

				<!-- Pagination -->
				<div class="pagination-wrapper ">
					<ul class="pagination pagination-sm">
						<li class="disabled"><a href="#">Previous</a></li>
						<li class="active"><a href="#">1</a></li>
						<li><a href="#">2</a></li>
						<li><a href="#">3</a></li>
						<li><a href="#">4</a></li>
						<li><a href="#">5</a></li>
						<li><a href="#">Next</a></li>
					</ul>
				</div>				
				</div>
			</div>
	    </div>

	 <?php get_footer(); ?>