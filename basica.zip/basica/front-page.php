<?php global $basica_theme; ?>
<?php get_header(); ?>
	
    <section id="main-slider" class="no-margin">
        <div class="carousel slide">
            <div class="carousel-inner">
			<?php 
			$basica_slider   = null;
			$basica_slider   = new WP_Query(array(
			'post_type'      => 'slider',
			'post_per_page'  => -1,
			'order'          => 'ASC'
			));
			
			if($basica_slider->have_posts() ){
				$x = 0;
				while($basica_slider->have_posts() ){
					$x++;
					$basica_slider->the_post();
                    $slider_thumb  = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'full' );
					?>
					
				<div class="item <?php if($x==1){echo 'active';} ?>" style="background-image: url(<?php echo $slider_thumb[0]; ?>)">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="carousel-content centered">
                                    <h2 class="animation animated-item-1"><?php the_title(); ?></h2>
                                    <p class="animation animated-item-2"><?php the_content(); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
					
					
					
				<?php }
			}else{
				echo 'No Post';
			}
			?>
				
                
            </div><!--/.carousel-inner-->
			<ol class="carousel-indicators">
			<?php 
			for($i=0; $i<$x; $i++){ ?>
				 <li data-target="#main-slider" data-slide-to="<?php echo $i; ?>" class="<?php if($i==0){echo 'active';} ?>"></li>	
			<?php }
			?>
            </ol>
			
			
        </div><!--/.carousel-->
        <a class="prev hidden-xs" href="#main-slider" data-slide="prev">
            <i class="icon-angle-left"></i>
        </a>
        <a class="next hidden-xs" href="#main-slider" data-slide="next">
            <i class="icon-angle-right"></i>
        </a>
    </section><!--/#main-slider-->

	
		<!-- Call to Action Bar -->
	    <div class="section section-dark">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="calltoaction-wrapper">
							<h3>Welcome to <span style="color:#aec62c; text-transform:uppercase;font-size:24px;">Basica!</span> A free fully responsive Bootstrap 3 HTML5 template!</h3> <a href="http://www.vactualart.com/portfolio-item/basica-a-free-html5-template/" class="btn btn-orange">Download here!</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Call to Action Bar -->


		<!-- Services -->
        <div class="section section-white">
	        <div class="container">
	        	<div class="row">
	        		<div class="col-md-4 col-sm-6">
	        			<div class="service-wrapper">
		        			<i class="icon-home"></i>
		        			<h3>Aliquam in adipiscing</h3>
		        			<p>Praesent rhoncus mauris ac sollicitudin vehicula. Nam fringilla turpis turpis, at posuere turpis aliquet sit amet condimentum</p>
		        			<a href="#" class="btn">Read more</a>
		        		</div>
	        		</div>
	        		<div class="col-md-4 col-sm-6">
	        			<div class="service-wrapper">
		        			<i class="icon-briefcase"></i>
		        			<h3>Curabitur mollis</h3>
		        			<p>Suspendisse eget libero mi. Fusce ligula orci, vulputate nec elit ultrices, ornare faucibus orci. Aenean lectus sapien, vehicula</p>
		        			<a href="#" class="btn">Read more</a>
		        		</div>
	        		</div>
	        		<div class="col-md-4 col-sm-6">
	        			<div class="service-wrapper">
		        			<i class="icon-calendar"></i>
		        			<h3>Vivamus mattis</h3>
		        			<p>Phasellus posuere et nisl ac commodo. Nulla facilisi. Sed tincidunt bibendum cursus. Aenean vulputate aliquam risus rutrum scelerisque</p>
		        			<a href="#" class="btn">Read more</a>
		        		</div>
	        		</div>
	        	</div>
	        </div>
	    </div>
	    <!-- End Services -->


<hr>

		<!-- Our Portfolio -->	

        <div class="section section-white">
	        <div class="container">
	        	<div class="row">
	
				<div class="section-title">
				<h1>Our Recent Works</h1>
				</div>
			<ul class="grid cs-style-3">
			<?php 
			if(is_array($basica_theme['our_recent_work'])){
				foreach($basica_theme['our_recent_work'] as $singleitem){?>	
			   <div class="col-md-4 col-sm-6">
				    <figure>
						<img src="<?php echo $singleitem['image']; ?>">
						<figcaption>
							<h3><?php echo $singleitem['title']; ?></h3>
							<span><?php echo $singleitem['description']; ?></span>
							<a href="<?php echo $singleitem['url']; ?>">Take a look</a>
						</figcaption>
					</figure>
	        	</div>	
				<?php }
			}
			?>	
			</ul>
	        	</div>
	        </div>
	    </div>
		<!-- Our Portfolio -->
			
<hr>

		<!-- Our Clients -->
	    <div class="section">
	    	<div class="container">
			
				<div class="section-title">
				<h1>Our Success Stories</h1>
				</div>

				<div class="clients-logo-wrapper text-center row">
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-1.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-2.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-3.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-4.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-5.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-6.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-7.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-8.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-9.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-10.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-11.jpg" alt="Client Name"></a></div>
					<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/logos/logo-12.jpg" alt="Client Name"></a></div>
				</div>
			</div>
	    </div>
	    <!-- End Our Clients -->
<?php get_footer(); ?>